/*
 StepMoto_THH ( X , 1 , 2 , 3 , 4 , c)
 X ->'F' �e�i    
 X ->'B' ��h 
 1,2,3,4 -> �B�i���F���barduino �����Ӹ}��
 c -> ������ 
*/

void StepMoto_THH(char , byte , byte , byte , byte , float);

void StepMoto_THH(char x,byte a,byte b,byte c,byte d , float z)
{
 int t= 1050;
 int i,j;
 boolean my_Inta[]={1,1,0,0,0,0,0,1};
 boolean my_Intb[]={0,1,1,1,0,0,0,0};
 boolean my_Intc[]={0,0,0,1,1,1,0,0};
 boolean my_Intd[]={0,0,0,0,0,1,1,1};	
 pinMode(a,OUTPUT);
 pinMode(b,OUTPUT);
 pinMode(c,OUTPUT);
 pinMode(d,OUTPUT);
 z=z*512;
 if (x=='B')
 {
  for (int j=0;j<z;j++)
  { 
   for(int i=0;i<8;i++)
   {
    digitalWrite(d,my_Inta[i]);
    digitalWrite(c,my_Intb[i]);
    digitalWrite(b,my_Intc[i]);
    digitalWrite(a,my_Intd[i]);
    delayMicroseconds(t);
   } 
  } 
 }
  if (x=='F')
 {
  for (int j=0;j<z;j++)
  { 
   for(int i=0;i<8;i++)
   {
    digitalWrite(a,my_Inta[i]);
    digitalWrite(b,my_Intb[i]);
    digitalWrite(c,my_Intc[i]);
    digitalWrite(d,my_Intd[i]);
    delayMicroseconds(t);
   } 
  } 
 }
}
